package com.example.family.recyclable;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final WebView webview = new WebView(this);
        setContentView(webview);
        webview.loadUrl("https://search.earth911.com/?what=" + MainActivity.object + "&where=&list_filter=all&max_distance=25&family_id=&latitude=40.3573&longitude=-74.6672&country=&province=&city=&sponsor=");
    }
}
