package com.example.family.recyclable;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {

    public static String object;
    EditText objectInput;
    Button button;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Context context = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        objectInput = (EditText) findViewById(R.id.objectInput);
        button = (Button) findViewById(R.id.button);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                object = objectInput.getText().toString();
                if(object.contains("Can") || object.contains("can")|| object.contains("Glass") || object.contains("glass") || object.contains("Container") || object.contains("paper") || object.contains("Book") || object.contains("Metal") || object.contains("metal") || object.contains("Paper") {
                    startActivity(new Intent(MainActivity.this, MainActivity2.class));
                    showToast("Recyclable");

                } else {
                    showToast("Not Recyclable -> Throw it in the trash");
                }
            }

        });


    }

    private void showToast(String text) {
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show();
    }
}
